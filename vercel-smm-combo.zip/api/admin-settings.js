const {getSettings,setValue,authorized}=require("./_store");
module.exports=async (req,res)=>{
  if(!authorized(req)) return res.status(401).json({error:"Unauthorized"});
  if(req.method==="GET"){
    const s=await getSettings(); return res.status(200).json({apiUrl:s.apiUrl,hasApiKey:Boolean(s.apiKey)});
  }
  if(req.method==="POST"){
    const current=await getSettings(), b=req.body||{};
    const s={apiUrl:String(b.apiUrl||current.apiUrl),apiKey:String(b.apiKey||current.apiKey)};
    await setValue("smm:settings",s);
    return res.status(200).json({success:true,apiUrl:s.apiUrl,hasApiKey:Boolean(s.apiKey)});
  }
  return res.status(405).json({error:"Method not allowed"});
};
