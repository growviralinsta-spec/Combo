const {getServices,setValue,authorized}=require("./_store");
module.exports=async (req,res)=>{
  if(!authorized(req)) return res.status(401).json({error:"Unauthorized"});
  try{
    let services=await getServices();
    if(req.method==="GET") return res.status(200).json(services);
    if(req.method==="POST"){
      const s=req.body||{};
      if(!s.id || !s.name) return res.status(400).json({error:"ID and name are required"});
      const clean={id:String(s.id),name:String(s.name),price:String(s.price||""),description:String(s.description||""),details:String(s.details||""),active:Boolean(s.active)};
      const i=services.findIndex(x=>String(x.id)===clean.id);
      if(i>=0) services[i]=clean; else services.push(clean);
      await setValue("smm:services",services); return res.status(200).json({success:true,services});
    }
    if(req.method==="DELETE"){
      const id=String(req.query.id||"");
      services=services.filter(s=>String(s.id)!==id);
      await setValue("smm:services",services); return res.status(200).json({success:true,services});
    }
    return res.status(405).json({error:"Method not allowed"});
  }catch(e){return res.status(500).json({error:"Storage not configured or unavailable"});}
};
