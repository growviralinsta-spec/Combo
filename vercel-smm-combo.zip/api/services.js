const {getServices}=require("./_store");
module.exports=async (req,res)=>{
  if(req.method!=="GET") return res.status(405).json({error:"Method not allowed"});
  try{
    const services=await getServices();
    res.status(200).json(services.filter(s=>s.active));
  }catch(e){res.status(500).json({error:"Unable to load services"});}
};
