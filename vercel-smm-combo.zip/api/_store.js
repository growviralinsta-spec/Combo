const DEFAULT_SERVICES = [
  {id:"1",name:"Starter Combo",price:"₹49",description:"Perfect for a quick boost.",details:"5,000 Views\n250 Likes\n500 Shares\nFast processing",active:true},
  {id:"2",name:"Growth Combo",price:"₹69",description:"More reach, more engagement.",details:"8,000 Views\n400 Likes\n1,000 Shares\nPriority processing",active:true},
  {id:"3",name:"Pro Combo",price:"₹99",description:"For creators ready to scale.",details:"15,000 Views\n750 Likes\n1,500 Shares\nPriority support",active:true}
];

function redisConfig(){
  return {url:process.env.UPSTASH_REDIS_REST_URL, token:process.env.UPSTASH_REDIS_REST_TOKEN};
}
async function redisCommand(command){
  const {url,token}=redisConfig();
  if(!url || !token) return null;
  const r=await fetch(url,{method:"POST",headers:{"Authorization":`Bearer ${token}`,"Content-Type":"application/json"},body:JSON.stringify(command)});
  if(!r.ok) throw new Error("Redis request failed");
  const d=await r.json(); return d.result;
}
async function getValue(key){
  const r=await redisCommand(["GET",key]);
  return r ? JSON.parse(r) : null;
}
async function setValue(key,value){
  await redisCommand(["SET",key,JSON.stringify(value)]);
}
async function getServices(){
  const stored=await getValue("smm:services");
  return Array.isArray(stored)?stored:DEFAULT_SERVICES;
}
async function getSettings(){
  const stored=await getValue("smm:settings");
  return {
    apiUrl: stored?.apiUrl || process.env.MRSMM_API_URL || "https://mrsmm.org/api/v2",
    apiKey: stored?.apiKey || process.env.MRSMM_API_KEY || "",
  };
}
function adminPassword(){return process.env.ADMIN_PASSWORD || "CHANGE_ME";}
function authorized(req){
  const h=req.headers["x-admin-password"] || "";
  return h && h === adminPassword();
}
module.exports={getServices,setValue,getSettings,adminPassword,authorized,redisConfig};
