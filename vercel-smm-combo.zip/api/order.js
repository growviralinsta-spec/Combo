const {getServices,getSettings}=require("./_store");
module.exports=async (req,res)=>{
  if(req.method!=="POST") return res.status(405).json({success:false,error:"Method not allowed"});
  try{
    const {service,link,quantity}=req.body||{};
    if(!service || !link) return res.status(400).json({success:false,error:"Missing service or link"});
    const services=await getServices();
    const selected=services.find(s=>String(s.id)===String(service) && s.active);
    if(!selected) return res.status(400).json({success:false,error:"Service unavailable"});
    const settings=await getSettings();
    if(!settings.apiKey) return res.status(500).json({success:false,error:"API key is not configured"});
    const r=await fetch(settings.apiUrl,{
      method:"POST",
      headers:{"Content-Type":"application/x-www-form-urlencoded"},
      body:new URLSearchParams({key:settings.apiKey,action:"add",service:String(selected.id),link:String(link),quantity:String(Math.max(1,Number(quantity)||1))})
    });
    const d=await r.json().catch(()=>null);
    if(!r.ok || !d) return res.status(502).json({success:false,error:"Invalid provider response"});
    if(d.order) return res.status(200).json({success:true,order:d.order});
    return res.status(400).json({success:false,error:d.error||"Order failed"});
  }catch(e){return res.status(502).json({success:false,error:"Provider connection failed"});}
};
